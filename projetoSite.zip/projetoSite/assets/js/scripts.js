// Inicializa o Parse com as credenciais do Back4App
Parse.initialize("ssj4SVeAvPGwGKK82M7QknL4G0xItCq1vYSp2k4H", "qWARIcypxFu1czaoyjktNfqAaa3DNPjBUA9lXW31");
Parse.serverURL = "https://parseapi.back4app.com/";

// Função de login
async function loginUser() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  try {
    const user = await Parse.User.logIn(username, password);
    alert('Login bem-sucedido!');
    showMainPage(); // Vai para a página principal após o login bem-sucedido
  } catch (error) {
    alert('Erro ao fazer login: ' + error.message);
  }
}

// Função de registro
async function registerUser() {
  const username = document.getElementById('newUsername').value;
  const email = document.getElementById('newEmail').value;
  const password = document.getElementById('newPassword').value;

  const user = new Parse.User();
  user.set("username", username);
  user.set("email", email);
  user.set("password", password);

  try {
    await user.signUp();
    alert('Usuário registrado com sucesso!');
    showLoginPage(); // Vai para a página de login após o registro bem-sucedido
  } catch (error) {
    alert('Erro ao registrar usuário: ' + error.message);
  }
}

// Função para exibir a página de login
function showLoginPage() {
  document.getElementById('loginPage').style.display = 'block';
  document.getElementById('registerPage').style.display = 'none';
  document.getElementById('mainPage').style.display = 'none';
}

// Função para exibir a página de registro
function showRegisterPage() {
  document.getElementById('loginPage').style.display = 'none';
  document.getElementById('registerPage').style.display = 'block';
  document.getElementById('mainPage').style.display = 'none';
}

// Função para exibir a página principal (dashboard)
function showMainPage() {
  document.getElementById('loginPage').style.display = 'none';
  document.getElementById('registerPage').style.display = 'none';
  document.getElementById('mainPage').style.display = 'block';
}

// Função para buscar os dados de clima na classe Records no Back4App
async function fetchWeatherData() {
  const WeatherData = Parse.Object.extend("Records");
  const query = new Parse.Query(WeatherData);

  try {
    const results = await query.find();
    if (results.length > 0) {
      displayWeatherData(results[0]); // Exibe o primeiro registro (se houver)
    } else {
      alert("Nenhum dado de clima encontrado.");
    }
  } catch (error) {
    alert("Erro ao recuperar dados de clima: " + error.message);
  }
}

// Função para exibir os dados de clima no dashboard
function displayWeatherData(weatherData) {
  const dataContainer = document.getElementById("dataContainer");
  const temperature = weatherData.get("temperature");
  const location = weatherData.get("location");
  const date = weatherData.get("date");

  const dataElement = document.createElement("div");
  dataElement.innerHTML = `
    <h3>Clima em ${location}</h3>
    <p><strong>Temperatura:</strong> ${temperature}°C</p>
    <p><strong>Data:</strong> ${date}</p>
  `;

  dataContainer.appendChild(dataElement);
}
